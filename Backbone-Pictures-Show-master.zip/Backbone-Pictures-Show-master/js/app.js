// 定义模块
define(function(require,exports,module){
	// 引入layerjs
	var LayerView = require('modules/layer/layer');
	// 引入listjs文件
	var ListView = require('modules/list/list');
	// 加载集合模块
	var ListCollection=require('modules/collection/imgCollection');
	// 实例化类
	var lc = new ListCollection();
	var Layer = new LayerView({
		el:$('.layer'),
		collection:lc
	});
	var List = new ListView({
		el:$('.list'),
		collection:lc
	});
	// 创建路由
	var Router = Backbone.Router.extend({
		// 定义路由规则
		routes:{
			// 定义主页
			'layer/:num':'showLayer',
			// 定义分页
			'*other':'showList'
		},
		// 定义showLayer方法
		showLayer:function(num){
			// 渲染页面
			Layer.render(num);
			Layer.$el.show();
			List.$el.hide();
		},
		// 定义showList方法
		showList:function(){
			Layer.$el.hide();
			List.$el.show();
			// 渲染页面
			// List.render()
		}
	})
	// 实例化路由类
	var R = new Router()
	// 开启路由
	Backbone.history.start();
})