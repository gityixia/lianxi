// 定义模块
define(function(require, exports, module) {
    // 引入css文件
    require('./list.css');
    // 定义类
    var View = Backbone.View.extend({
            // 绑定事件
            events: {
                'tap .search .sou': 'searchImg',
                // 注册事件，事件委托
                'tap .imgType': 'searchImgType',
                // 注册返回顶部事件
                'tap .go-top': 'goTop',
                // 添加返回主页事件
                'tap .go-back':'goBack'
            },
            // 定义模板
            tpl: _.template('<a href="<%=link%>"><img style="<%=style%>" src="<%=src%>" alt="" /></a>'),
            // 保存容器宽高
            leftHeight: 0,
            rightHeight: 0,
            // 定义初始化方法
            initialize: function() {
                // 保存this
                var me = this;
                // 缓存dom元素
                this.initDom();
                // 跨对象监听collection事件
                this.listenTo(this.collection, 'add', function(model, collection) {
                        // 渲染视图
                        this.render(model);
                    })
                    // 请求数据（触发集合的add事件），所以请求数据要在注册事件后面
                this.collection.fetchData();
                // 定义节流函数
                var fn = _.throttle(function() {
                        me.collection.fetchData();
                    })
                    // 注册scroll事件
                $(window).on('scroll', function() {
                    if ($('body').height() < $(window).scrollTop() + $(window).height() + 200) {
                        fn();
                    }
                    // 显示返回顶部按钮
                    me.showGoTop();
                })
            },
            showGoTop: function() {
                if ($(window).scrollTop() > 300) {
                    this.$el.find('.go-top').show();
                } else {
                    this.$el.find('.go-top').hide();
                }
            },
            // 定义searchImg方法
            searchImg: function() {
                // 获取输入的值
                var value = this.getValue();
                // 检测输入是否正确 true是输入不正确 false表示输入正确
                // 如果输入正确，继续过滤，否则终止进程
                if (this.checkInputErr(value)) {
                    return alert('请输入内容');
                }
                // 处理输入的内容,进行空格过滤
                value = value.replace(/^\s|\s$/g, '');
                // 过滤,得到models集合数组
                var result = this.filterInput(value);
                // 清空图片显示区域内容
                this.clearImg();
                // 渲染视图
                this.renderResult(result);
                if(result.length==0){
                  return this.$el.find('.imgs span').html('没有找到你要搜索的图片').show();
                }
            },
            // 渲染数组类型的models数据
            renderResult: function(result) {
                // 保存this
                var me = this;
                result.forEach(function(model, index) {
                    me.render(model);
                })
            },
            // 定义清空图片显示区域内容方法
            clearImg: function() {
                // 清空左右容器内容
                this.leftDom.html('');
                this.rightDom.html('');
                // 清空高度
                this.leftHeight = 0;
                this.rightHeight = 0;
            },
            // 定义过滤方法
            filterInput: function(value, type) {
                return this.collection.filter(function(model, index, models) {
                    if (type == 'type') {
                        return model.get('type') == value;
                    }
                    return model.get('title').indexOf(value) > -1;
                })
            },
            // 定义检测方法
            checkInputErr: function(value) {
                // value不为空即可
                if (/^\s*$/.test(value)) {
                    return true;
                }
                return false;
            },
            // 定义缓存dom元素的方法
            initDom: function() {
                // 获取元素
                this.leftDom = this.$el.find('.imgs-left');
                this.rightDom = this.$el.find('.imgs-right');
                // 获取搜索框元素
                this.inputDom = this.$el.find('.input');
                // 获取球星图标，设置高度
                var height = $(window).width() / 8;
                this.$el.find('.imgType li').css('height', height);
                this.$el.find('.imgType').css('height', height);
                // this.$el.find('.imgType li img').css('marginLeft', -height/2);
            },
            // 定义getValue方法
            getValue: function() {
                return this.inputDom.val();
            },
            // 定义渲染方法
            render: function(model) {
                var height = model.get('viewHeight');
                // 获取元素
                // 获取数据
                var data = {
                        link: '#layer/' + model.get('id'),
                        style: 'width:' + model.get('viewWidth') + 'px;height:' + height + 'px;',
                        src: model.get('url')
                    }
                    //定义模板
                var tpl = this.tpl;
                // 格式化模板
                var html = tpl(data);
                // 判断情况，进行渲染
                if (this.leftHeight <= this.rightHeight) {
                    // 渲染左边
                    this.renderLeft(html, height);
                } else {
                    // 渲染右边
                    this.renderRight(html, height);
                }
            },
            // 渲染左边方法
            renderLeft: function(html, height) {
                this.leftDom.append(html);
                // 更新高度
                this.leftHeight += height + 6;
            },
            // 渲染右边方法
            renderRight: function(html, height) {
                this.rightDom.append(html);
                // 更新高度
                this.rightHeight += height + 6;
            },
            // 定义type事件
            searchImgType: function(e) {
                // 隐藏提示
                this.$el.find('.imgs span').hide();
                // 更改当前元素的样式
                $(e.target).parent().addClass('color');
                $(e.target).parent().siblings().removeClass('color');
                // 获取当前点击元素的内容
                var value = $(e.target).data('id');
                // 过滤，获取数据
                var result = this.filterInput(value, 'type');
                // 清除显示区域
                this.clearImg();
                // 渲染
                this.renderResult(result);
            },
            // 定义返回顶部事件
            goTop: function() {
                this.scrollAnimate(100);
                // this.goTop1();
            },
            // 定义滚动动画函数
            scrollAnimate: function(time) {
                var t = time/20;
                // 获取当前滚动值
                var value = $(window).scrollTop();
                // 定义第一次的步长
                var timer = setInterval(function(){
                    index = value / t;
                    t++;
                    window.scrollBy(0,-index);
                    if($(window).scrollTop() === 0){
                        clearInterval(timer);
                    }
                },20);
            },
            goTop1: function () {
            var time = 500;
            var count = Math.floor(500 / 30);
            var top =  $(window).scrollTop();
            var stop = top / count;
            var c = 0;
            var speed = 15;
            var end = 0;
            var timer = setInterval(function () {
                window.scrollBy(0,-stop);
                c++;
                if (c >= count) {
                    window.scrollTo(0,end);
                    clearInterval(timer);
                }
            }, speed);
        },
            //定义goBack事件
            goBack:function(){
                // 隐藏提示
                this.$el.find('.imgs span').hide();
                // 重新渲染显示区
                this.renderResult(this.collection.models);
            }

        });
        // 暴露接口
    module.exports = View;
});
