// 定义模块
define(function(require, exports, module) {
    // 获取容器宽度
    var w = $(window).width() / 2 - 6 - 3;
    // 定义模型类
    var imgModel = Backbone.Model.extend({
        // 定义构造函数
        initialize:function(){
        	// 计算图片的高度
        	var h = this.attributes.height / this.attributes.width * w;
        	// 添加到model属性中
        	this.attributes.viewHeight = h;
        	this.attributes.viewWidth = w;
        }
    })
    // 暴露接口
    module.exports = imgModel;
})
