// 定义模块
define(function(require, exports, module) {
    // 引入模型
    var imgModel = require('modules/model/imgModel');
    // 定集合类
    var collection = Backbone.Collection.extend({
        // 定义默认集合
        model: imgModel,
        // 定义变量，记录模型（图片）id
        idNum: 0,
        /**
         * 定义获取数据方法
         * 1	对返回的结果随机排序
         * 2	给model添加id
         */
        fetchData: function() {
            // 保存this
            var me = this;
            // 发送ajax请求，获取数据
            $.get('data/imageList.json', function(res) {
                if (res && res.errno == 0) {
                    // 对数据随机排序
                    res.data.sort(function(a,b){
                    	// 返回随机
                    	return Math.random()> .5 ? true : false;
                    })
                    // 为每一个成员添加一个ID、
                    res.data.forEach(function(obj,index){
                    	obj.id = ++ me.idNum;
                    })
                    me.add(res.data)
                }
            })
        }
    })
    // 暴露接口
    module.exports = collection;
    // // 测试
    // var c = new collection();
    // c.fetchData()
})
