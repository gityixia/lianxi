// 定义模块
define(function(require,exports,module){
	// 引入css文件
	require('./layer.css');
	// 获取窗口的高度
	var height = $(window).height();
	// 定义类
	var View = Backbone.View.extend({
		// 保存当前显示的图片的id
		nowImgId:0,
		// 定义模板
		tpl:_.template($('#template').html()),
		// 添加事件
		events:{
			// 添加go-back事件
			'tap .white':'goBack',
			// 添加swipeLeft事件
			'swipeLeft .container img':'swipeLeft',
			// 添加向右滑动事件swipeRight
			'swipeRight .container img':'swipeRight',
			// 添加显隐事件
			'tap .container':'h1Toggle'
		},
		// 定义h1Toggle事件
		h1Toggle:function(){
			this.$el.find('header').toggle();
		},
		// 定义swipeRight事件
		swipeRight:function(){
			this.nowImgId--;
			// 获取数据，判断是否是最后 一张图片
			var model = this.collection.get(this.nowImgId);
			if(model){
				this.$el.find('.note').hide();
				this.updateView(model);
			}else{
				this.nowImgId++;
				this.$el.find('.note').html('没有上一张了').show();
				return ;
			}
		},
		// 定义swipeLeft事件,显示下一张图片
		swipeLeft:function(){
			this.nowImgId++;
			// 获取数据，判断是否是最后 一张图片
			var model = this.collection.get(this.nowImgId);
			if(model){
				this.$el.find('.note').hide();
				this.updateView(model);
			}else{
				this.nowImgId--;
				this.$el.find('.note').html('没有下一张了').show();
				return;
			}
		},
		// 定义updateView方法
		updateView:function(model){
			// 获取元素，更新内容
			this.$el.find('header h1').html(model.get('title'));
			this.$el.find('.container img').attr('src', model.get('url'));
		},
		// 定义goBack事件
		goBack:function(){
			// 返回list页面
			window.location.hash = '';
		},
		// 渲染视图
		render:function(num){
			// 获取数据
			var model = this.collection.get(num);
			// 判断是否存在
			if(!model){
				// 返回list页面
				window.location.hash = '';
				return;
			}
			// 存储当前模型的id
			this.nowImgId = model.get('id');
			// 获取数据，准备渲染图片
			var data = {
				title:model.get('title'),
				style:'line-height:'+ height+'px',
				src:model.get('url')
			};
			// 格式化模板
			var html = this.tpl(data);
			// 渲染页面
			this.$el.html(html);
		}
	})
	// 暴露接口
	module.exports = View;
})