# 手机端图片浏览网站SPA

## 说明

本项目是基于Backbone框架开发的，所有数据均为静态资源，仅供学习

## 预览
<div style="height:450px;float:left;"><img src="http://i.imgur.com/1qmkPYb.png" style="width:200px; " /></div>
<div style="height:450px;float:left;"><img src="http://i.imgur.com/MYKzCuI.png"  style="width:200px;" /></div>
<div style="height:450px;float:left;"><img src="http://i.imgur.com/ir0old4.png!"  style="width:200px;" /></div>


## 运行 ##


- 使用git克隆到本地  
- 使用Node运行根目录的app.js文件
- 浏览器地址栏输入localhost:3000

