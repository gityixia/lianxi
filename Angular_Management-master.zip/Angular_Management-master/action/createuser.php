<?php

$res = array(
	"data" => array(),
	"errno" => 0
);
echo json_encode($res);