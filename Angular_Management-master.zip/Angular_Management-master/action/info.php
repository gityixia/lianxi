<?php
$result = array(
	"errno" => 0
);
echo json_encode($result);