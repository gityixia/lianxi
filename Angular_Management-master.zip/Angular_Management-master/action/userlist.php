<?php
$data = array(
	array(
		"Username" => "Lina",
		"Department" => "Development",
		"Status" => "Working"
	),
	array(
		"Username" => "Lina",
		"Department" => "Development",
		"Status" => "Working"
	),
	array(
		"Username" => "Lina",
		"Department" => "Development",
		"Status" => "Working"
	),
	array(
		"Username" => "Lina",
		"Department" => "Development",
		"Status" => "Working"
	),
	array(
		"Username" => "Lina",
		"Department" => "Development",
		"Status" => "Working"
	)
);
$result = array(
	"errno" => 0,
	"data" => $data
);
echo json_encode($result);