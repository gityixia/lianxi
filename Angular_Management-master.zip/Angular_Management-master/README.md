# 博客平台管理系统
## 说明
本项目是基于Angularjs开发的博客平台管理系统，所有数据均为静态资源，仅供学习！  
>** 注意：**由于本项目是采用modjs进行模块化的，需要fis3配合并且打包才能实现，static是打包后的文件。文件运行时加载这里面的文件
## 预览
<div style="height:450px;float:left;"><img src="http://i.imgur.com/LFr5VPk.png" style="width:200px; " /></div>
<div style="height:450px;float:left;"><img src="http://i.imgur.com/cU9isRT.png"  style="width:200px;" /></div>
<div style="height:450px;float:left;"><img src="http://i.imgur.com/JNrUF6E.png!"  style="width:200px;" /></div>
<div style="height:450px;float:left;"><img src="http://i.imgur.com/75a1O53.png!"  style="width:200px;" /></div>


## 运行 ##


- 使用git克隆到本地  
- 后台文件使用的php语言开发的，需要本地服务器
- 放到Apache服务器或者其他可以解析php的本地服务器目录下

